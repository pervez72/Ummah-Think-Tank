
export interface Pillar {
  title: string;
  description: string;
}

export interface NavLink {
  label: string;
  href: string;
  dropdown?: NavLink[];
}
