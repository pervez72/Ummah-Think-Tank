
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="text-center py-8 mt-16 bg-[#1E1E1E] border-t border-white/10">
      <p className="text-sm text-[#A0A0A0]">
        © 2024 Ummah Think Tank. All rights reserved. 
        <br />
        Developed by <a href="https://asuxai.com/" target="_blank" rel="noopener noreferrer" className="text-[#30DEB0] font-semibold hover:underline">AsuX AI</a>.
      </p>
    </footer>
  );
};

export default Footer;
