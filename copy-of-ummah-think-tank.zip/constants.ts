
import { Pillar, NavLink } from './types';

export const PILLAR_DATA: Pillar[] = [
  {
    title: 'Intellectual Renaissance',
    description: 'We publish research, host debates, and develop frameworks that connect timeless Islamic principles with contemporary challenges in economics, philosophy, and governance.',
  },
  {
    title: 'Technology & Innovation',
    description: 'We are a policy and ethics lab exploring AI, data privacy, and digital literacy. We aim to incubate technology that serves community needs and promotes digital sovereignty.',
  },
  {
    title: 'Socio-Economic Response',
    description: 'We research and model effective, data-driven solutions for humanitarian aid, sustainable development (SDGs), and community-led crisis management to build resilience.',
  },
];

export const NAV_LINKS: NavLink[] = [
  { label: 'Home', href: '#' },
  { label: 'About Us', href: '#' },
  { label: 'Pillars', href: '#' },
  { 
    label: 'Research', 
    href: '#',
    dropdown: [
      { label: 'White Papers', href: '#' },
      { label: 'Case Studies', href: '#' },
      { label: 'Policy Briefs', href: '#' },
    ]
  },
  { label: 'Contact', href: '#' },
];
