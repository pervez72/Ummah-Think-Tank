
import React, { useRef } from 'react';
import { useOnScreen } from '../hooks/useOnScreen';
import { Pillar } from '../types';

interface PillarCardProps extends Pillar {
    index: number;
}

const PillarCard: React.FC<PillarCardProps> = ({ title, description, index }) => {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useOnScreen(ref, '-100px');
  const delay = index * 150;

  return (
    <div
      ref={ref}
      className={`bg-[#1E1E1E] p-6 rounded-lg border border-white/10 text-left transition-all ease-out duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
      style={{ transitionDelay: `${isVisible ? delay : 0}ms` }}
    >
      <h3 className="font-montserrat text-xl font-bold text-[#30DEB0] mb-3">
        {title}
      </h3>
      <p className="text-base text-[#A0A0A0] leading-relaxed">
        {description}
      </p>
    </div>
  );
};

export default PillarCard;
