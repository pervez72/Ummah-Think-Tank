
import React, { useRef } from 'react';
import { useOnScreen } from '../hooks/useOnScreen';

const CallToAction: React.FC = () => {
    const ref = useRef<HTMLDivElement>(null);
    const isVisible = useOnScreen(ref, '-100px');

  return (
    <section 
      ref={ref}
      className={`py-12 my-8 text-center transition-opacity duration-700 ease-out transform ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
      >
      <h2 className="font-montserrat text-4xl font-bold text-[#FAFAFA] mb-4">Join the Conversation</h2>
      <p className="text-lg text-[#A0A0A0] max-w-3xl mx-auto mt-4 leading-relaxed">
        Read our latest white papers, engage with our research, or subscribe to our weekly insights brief.
      </p>
      <a 
        href="#" 
        className="inline-block bg-[#30DEB0] text-[#121212] py-3 px-7 mt-6 font-montserrat font-bold rounded-lg transition-all duration-300 ease-out hover:scale-105 hover:shadow-[0_0_15px_rgba(48,222,176,0.7)]"
      >
        Read Our Research
      </a>
    </section>
  );
};

export default CallToAction;
