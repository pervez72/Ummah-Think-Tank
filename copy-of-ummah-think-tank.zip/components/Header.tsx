
import React, { useState } from 'react';
import { NAV_LINKS } from '../constants';
import { NavLink } from '../types';

const NavItem: React.FC<{ item: NavLink }> = ({ item }) => {
  const [isDropdownOpen, setDropdownOpen] = useState(false);

  return (
    <li 
      className="relative"
      onMouseEnter={() => setDropdownOpen(true)}
      onMouseLeave={() => setDropdownOpen(false)}
    >
      <a href={item.href} className="text-[#A0A0A0] font-semibold transition-colors duration-300 hover:text-[#30DEB0]">
        {item.label}
      </a>
      {item.dropdown && isDropdownOpen && (
        <ul className="absolute top-full left-0 mt-2 w-48 bg-[#1E1E1E] border border-gray-700 rounded-md shadow-lg py-2 z-20 transition-opacity duration-300 opacity-100">
          {item.dropdown.map(subItem => (
            <li key={subItem.label}>
              <a href={subItem.href} className="block px-4 py-2 text-sm text-[#A0A0A0] hover:bg-gray-700 hover:text-[#30DEB0]">
                {subItem.label}
              </a>
            </li>
          ))}
        </ul>
      )}
    </li>
  );
};

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 flex justify-between items-center py-5 px-[5%] bg-black/80 backdrop-blur-md border-b border-white/10">
      <a href="#" className="font-montserrat text-2xl font-bold text-[#FAFAFA]">
        Ummah <span className="text-[#30DEB0]">Think Tank</span>
      </a>
      <nav>
        <ul className="flex space-x-8">
          {NAV_LINKS.map(link => (
            <NavItem key={link.label} item={link} />
          ))}
        </ul>
      </nav>
    </header>
  );
};

export default Header;
