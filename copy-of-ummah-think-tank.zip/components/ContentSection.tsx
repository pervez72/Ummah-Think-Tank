
import React, { useRef, ReactNode } from 'react';
import { useOnScreen } from '../hooks/useOnScreen';

interface ContentSectionProps {
  title: string;
  paragraph?: string;
  children?: ReactNode;
}

const ContentSection: React.FC<ContentSectionProps> = ({ title, paragraph, children }) => {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useOnScreen(ref, '-100px');

  return (
    <section 
      ref={ref} 
      className={`py-12 my-8 text-center transition-opacity duration-700 ease-out transform ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
    >
      <h2 className="font-montserrat text-4xl font-bold text-[#FAFAFA] mb-4 inline-block border-b-2 border-[#30DEB0] pb-2">
        {title}
      </h2>
      {paragraph && (
        <p className="text-lg text-[#A0A0A0] max-w-3xl mx-auto mt-4 leading-relaxed">
          {paragraph}
        </p>
      )}
      {children}
    </section>
  );
};

export default ContentSection;
