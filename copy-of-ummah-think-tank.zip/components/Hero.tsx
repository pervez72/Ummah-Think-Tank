
import React, { useRef } from 'react';
import { useOnScreen } from '../hooks/useOnScreen';

const Hero: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useOnScreen(ref);

  return (
    <section 
      ref={ref}
      className={`min-h-[40vh] flex flex-col justify-center items-center text-center py-20 px-5 transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <h1 className="font-montserrat text-5xl md:text-6xl font-bold text-[#FAFAFA] mb-4">
        Forging <span className="text-[#30DEB0]">Solutions</span>
      </h1>
      <p className="text-xl text-[#A0A0A0] max-w-2xl mx-auto">
        Bridging timeless values with modern intellect for the 21st-century Ummah.
      </p>
    </section>
  );
};

export default Hero;
