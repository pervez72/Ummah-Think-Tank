
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ContentSection from './components/ContentSection';
import PillarCard from './components/PillarCard';
import CallToAction from './components/CallToAction';
import Footer from './components/Footer';
import { PILLAR_DATA } from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <div className="max-w-4xl mx-auto px-5">
          <ContentSection 
            title="Our Perspective"
            paragraph="The Muslim Ummah faces unique challenges, from ethical AI to climate change and information gaps. 'Ummah Think Tank' exists to bridge this divide, forging solutions rooted in our values and powered by data-driven, critical analysis."
          />
          
          <ContentSection title="Our Core Pillars">
            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
              {PILLAR_DATA.map((pillar, index) => (
                <PillarCard 
                  key={pillar.title}
                  title={pillar.title}
                  description={pillar.description}
                  index={index}
                />
              ))}
            </div>
          </ContentSection>

          <CallToAction />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
